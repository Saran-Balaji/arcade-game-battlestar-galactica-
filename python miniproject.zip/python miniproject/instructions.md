 # pythonminiproject
Arcade game using pygame
Instructions:
1.Check if the latest version of python is in installed in your device.(a few old versions will also work)
2.Now open command prompt and see if pygame module is downloaded.
3.If not use the code 'pip install pygame' in command prompt and press enter to download.
4.Next download and unzip the python miniproject file to get access to its contents.
5.Now open the python file named arcade game to run the program.
6.Use 'r' key to start the game and use arrowkeys and space bar for direction and shooting respectively.
7.Objective of the game is to kill alien spacecraft,move away from from enemy lasers and remove obstacles using ypur own laser.
8.Your score will be displayed at the end.  
